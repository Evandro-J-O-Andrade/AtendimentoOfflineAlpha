# MD 1 — ARQUITETURA CANÔNICA DA PLATAFORMA

## Definição
DB-Driven Distributed Workflow Engine (MySQL como runtime)

## Camadas
- Frontend React
- API Layer Node/PHP
- SP Master Layer
- Domain Execution Layer
- Event + State Layer (fragmentado)

