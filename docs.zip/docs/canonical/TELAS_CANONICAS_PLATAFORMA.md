Acho que vocês precisam de **dois arquivos canônicos**:

1. `ARQUITETURA_FRONTEND_CANONICA.md` → regras para a IA não quebrar nada.
2. `TELAS_CANONICAS_PLATAFORMA.md` → inventário completo das telas que devem existir.

O segundo arquivo é o que vai permitir mostrar algo funcional para cliente sem sair criando páginas aleatórias.

---

# TELAS_CANONICAS_PLATAFORMA.md

```md
# NEW WAVE PLATFORM
# INVENTÁRIO CANÔNICO DE TELAS

Versão: 1.0
Status: Fundação da Plataforma

---

# 1. JORNADA GLOBAL

LOGIN
 ↓
PORTAL CORPORATIVO
 ↓
SELEÇÃO DE CONTEXTO
 ↓
SISTEMA
 ↓
UNIDADE
 ↓
LOCAL
 ↓
DASHBOARD
 ↓
TELAS OPERACIONAIS

---

# 2. LOGIN

Tela:
LoginPage

Objetivo:
Autenticar usuário.

Componentes:

- Logo NW
- Login
- Senha
- Entrar
- Recuperar Senha
- Versão do sistema

Retornos:

- JWT
- Refresh Token
- Sessão

---

# 3. PORTAL CORPORATIVO

Tela:
PortalHomePage

Objetivo:
Hub principal da plataforma.

Componentes:

- Header
- Busca Global
- Menu Sistemas
- Notícias
- Comunicados
- Calendário
- Atividades Recentes
- Favoritos
- Dashboard Executivo

Cards:

- HIS
- CRM
- ERP
- RH
- Financeiro
- Farmácia
- PDV
- Estoque
- Atendimento
- Portal Social

---

# 4. SELEÇÃO DE CONTEXTO

Tela:
ContextoOperacionalPage

Objetivo:
Definir ambiente operacional.

Fluxo:

Sistema
 ↓
Unidade
 ↓
Local

Exemplo:

Sistema:
HIS

Unidade:
UPA CENTRO

Local:
CONSULTÓRIO 03

---

# 5. DASHBOARD GLOBAL

Tela:
DashboardGlobal

Objetivo:
Visão geral.

Widgets:

- Sessões Ativas
- Usuários Online
- Sistemas Ativos
- Alertas
- Tarefas
- Eventos
- Notícias

---

# 6. PORTAL SOCIAL

Tela:
SocialFeedPage

Objetivo:
Rede social corporativa.

Componentes:

- Nova postagem
- Feed
- Curtidas
- Comentários
- Compartilhamentos

---

# 7. COMUNICADOS

Tela:
ComunicadosPage

Objetivo:
Avisos corporativos.

Componentes:

- Lista
- Leitura obrigatória
- Confirmação de ciência

---

# 8. NOTÍCIAS

Tela:
NoticiasPage

Objetivo:
Portal de notícias.

Componentes:

- Destaques
- Categorias
- Pesquisa
- Notícias

---

# 9. CALENDÁRIO

Tela:
CalendarioPage

Objetivo:
Agenda corporativa.

Componentes:

- Mensal
- Semanal
- Diário

Eventos:

- Reuniões
- Treinamentos
- Avisos

---

# 10. WIKI

Tela:
WikiPage

Objetivo:
Base de conhecimento.

Componentes:

- Artigos
- Categorias
- Histórico

---

# 11. CHAT

Tela:
ChatPage

Objetivo:
Mensageria corporativa.

Componentes:

- Contatos
- Grupos
- Conversas
- Anexos

---

# 12. PERFIL

Tela:
PerfilPage

Objetivo:
Dados da pessoa.

Componentes:

- Foto
- Nome
- Cargo
- Sistemas
- Unidades
- Permissões

---

# 13. ADMINISTRAÇÃO

Tela:
AdministracaoPage

Objetivo:
Governança.

Módulos:

- Pessoas
- Usuários
- Perfis
- Permissões
- Sistemas
- Unidades
- Locais

---

# 14. MONITORAMENTO

Tela:
MonitoramentoPage

Objetivo:
Operação da plataforma.

Widgets:

- APIs
- Banco
- N8N
- Filas
- WebSocket

---

# 15. AUDITORIA

Tela:
AuditoriaPage

Objetivo:
Rastreabilidade.

Filtros:

- Pessoa
- Usuário
- Sessão
- Sistema
- Unidade
- Local

---

# 16. CONFIGURAÇÕES

Tela:
ConfiguracoesPage

Objetivo:
Parâmetros.

Componentes:

- Branding
- Logo
- Cores
- Tema
- Integrações

---

# 17. DASHBOARD EXECUTIVO

Tela:
ExecutiveDashboard

Objetivo:
Visão estratégica.

Indicadores:

- Usuários
- Sessões
- Receita
- Operações
- SLA
- Produtividade

---

# 18. HIS

Sistema:
HIS

Dashboard:

- Fila
- Atendimento
- Classificação
- Médico
- Enfermagem

---

# 19. FARMÁCIA

Sistema:
Farmácia

Dashboard:

- Estoque
- Lotes
- Dispensação
- Inventário

---

# 20. PDV

Sistema:
PDV

Dashboard:

- Vendas
- Caixa
- Produtos
- Clientes

---

# 21. CRM

Sistema:
CRM

Dashboard:

- Leads
- Clientes
- Pipeline
- Campanhas

---

# 22. RH

Sistema:
RH

Dashboard:

- Funcionários
- Férias
- Ponto
- Treinamentos

---

# 23. ERP

Sistema:
ERP

Dashboard:

- Financeiro
- Compras
- Estoque
- Fiscal

---

# 24. FOOTER GLOBAL

Componentes:

- Nome da Plataforma
- Sistema Atual
- Unidade Atual
- Local Atual
- Sessão
- Versão
- Ambiente

Exemplo:

NEW WAVE PLATFORM
HIS
UPA CENTRO
CONSULTÓRIO 03
SESSÃO 8745
v1.0.0

---

# 25. HEADER GLOBAL

Componentes:

- Logo
- Busca
- Alertas
- Chat
- Perfil
- Contexto

---

# REGRA IMUTÁVEL

Nenhuma tela acessa banco diretamente.

Fluxo obrigatório:

React
 ↓
API Gateway
 ↓
Backend
 ↓
Dispatcher
 ↓
SP Executor
 ↓
Banco

PROIBIDO:

React → Banco

React → SQL

Node → UPDATE direto

Node → INSERT direto

Toda gravação obrigatoriamente via Stored Procedure.
```

Esse arquivo já serve como **catálogo oficial de telas da plataforma New Wave**, cobrindo Portal, Social, Wiki, Chat, Administração, Monitoramento, HIS, ERP, CRM, RH, PDV e Farmácia, mantendo a visão SaaS B2B/B2C Enterprise que vocês definiram.
