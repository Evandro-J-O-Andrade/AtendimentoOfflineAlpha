# ARQUITETURA_IMUTAVEL_PLATAFORMA_NEW_WAVE.md

# CONSTITUIÇÃO ARQUITETURAL DA PLATAFORMA

**Versão:** 1.0
**Status:** CANÔNICO
**Aplicação:** Plataforma New Wave (SaaS B2B / B2C / Enterprise)
**Obrigatório para:** Frontend, Backend, Banco de Dados, Integrações, IA, N8N e Automação.

---

# 1. OBJETIVO

Este documento define as leis imutáveis da Plataforma New Wave.

Nenhuma IA, desenvolvedor, automação ou ferramenta pode alterar estas regras sem autorização explícita.

Este documento possui precedência sobre qualquer documentação secundária.

---

# 2. LEIS IMUTÁVEIS

## LEI 001 — BANCO É A FONTE DA VERDADE

O Banco de Dados é a única fonte oficial da verdade.

Frontend não possui regra de negócio.

Backend não possui regra de negócio.

N8N não possui regra de negócio.

A regra de negócio reside exclusivamente nas Stored Procedures.

---

## LEI 002 — PROIBIÇÃO DE ALTERAÇÃO ESTRUTURAL

É proibido:

* Criar tabelas sem autorização.
* Alterar tabelas sem autorização.
* Renomear tabelas.
* Criar SPs sem autorização.
* Alterar SPs sem autorização.
* Renomear SPs.
* Criar motores paralelos.
* Criar arquiteturas alternativas.

---

## LEI 003 — ORDEM ONTOLÓGICA OBRIGATÓRIA

Toda operação deve respeitar:

SAAS_ENTIDADE
→ PESSOA
→ USUARIO
→ SESSAO_USUARIO
→ SISTEMA
→ UNIDADE
→ LOCAL
→ WORKFLOW
→ EVENTO
→ AUDITORIA

Nenhuma camada pode ser ignorada.

---

## LEI 004 — USUARIO NÃO É A ENTIDADE RAIZ

A entidade raiz humana é:

PESSOA

USUARIO representa apenas:

* credencial
* autenticação
* acesso

Toda identidade real pertence à tabela PESSOA.

---

## LEI 005 — PROIBIÇÃO DE MOTORES DUPLICADOS

É proibido criar:

* Login paralelo
* Sessão paralela
* Agenda paralela
* Auditoria paralela
* Workflow paralelo
* Permissões paralelas
* Alertas paralelos

Sempre reutilizar o núcleo existente.

---

## LEI 006 — TODA GRAVAÇÃO PASSA PELO DISPATCHER

Fluxo obrigatório:

API
→ DISPATCHER
→ EXECUTOR
→ STORED PROCEDURE
→ BANCO

É proibido:

Controller → INSERT

Controller → UPDATE

Controller → DELETE

diretamente em tabelas.

---

## LEI 007 — TRIGGERS PROIBIDOS

Não utilizar:

* Trigger BEFORE INSERT
* Trigger AFTER INSERT
* Trigger BEFORE UPDATE
* Trigger AFTER UPDATE

Toda lógica pertence às Stored Procedures.

---

# 3. ONTOLOGIA OFICIAL

## HIERARQUIA CORPORATIVA

SAAS_ENTIDADE
│
└── PESSOA
│
└── USUARIO
│
└── SESSAO_USUARIO
│
└── SISTEMA
│
└── UNIDADE
│
└── LOCAL
│
└── WORKFLOW
│
└── EVENTO
│
└── AUDITORIA

---

# 4. DOMÍNIOS DA PLATAFORMA

A Plataforma New Wave é uma plataforma SaaS.

O HIS é apenas um dos sistemas.

## Sistemas permitidos

PORTAL

HIS

CRM

PDV

FINANCEIRO

RH

ESTOQUE

FARMÁCIA

DASHBOARD

SOCIAL

WIKI

CHAT

ADMIN

INTEGRAÇÕES

AUTOMAÇÕES

---

# 5. FLUXO DE LOGIN

USUARIO
↓
LOGIN
↓
API AUTH
↓
SP_MASTER_DISPATCHER
↓
AUTH.LOGIN
↓
SESSAO_USUARIO
↓
PORTAL CORPORATIVO

---

# 6. FLUXO DO PORTAL

PORTAL
│
├── Home
├── Notícias
├── Comunicados
├── Calendário
├── Dashboard
├── Wiki
├── Chat
├── Social
├── Integrações
├── Documentos
├── Aplicações
└── Configurações

---

# 7. FLUXO DE APLICAÇÕES

PORTAL
↓
APLICAÇÕES
↓
SELECIONAR SISTEMA
↓
SELECIONAR UNIDADE
↓
SELECIONAR LOCAL
↓
ATUALIZAR CONTEXTO
↓
ABRIR SISTEMA

---

# 8. TROCA DE SISTEMA

A sessão permanece ativa.

Não gerar novo login.

Não gerar nova sessão.

Alterar apenas:

* id_sistema
* id_unidade
* id_local

---

# 9. FLUXO FRONTEND

TELA
↓
HOOK
↓
SERVICE
↓
API CLIENT
↓
BACKEND

Nunca:

TELA
↓
BANCO

Nunca:

TELA
↓
MYSQL

---

# 10. FLUXO BACKEND

ROTA
↓
CONTROLLER
↓
SERVICE
↓
DISPATCHER
↓
EXECUTOR
↓
STORED PROCEDURE
↓
BANCO

---

# 11. FLUXO N8N

N8N NÃO ACESSA TABELAS.

N8N NÃO EXECUTA INSERT.

N8N NÃO EXECUTA UPDATE.

N8N NÃO EXECUTA DELETE.

Fluxo obrigatório:

N8N
↓
WEBHOOK
↓
API
↓
DISPATCHER
↓
SP
↓
BANCO

---

# 12. FRONTEND CANÔNICO

src/

shell/

apps/

modules/

shared/

assets/

styles/

runtime/

---

## SHELL

Auth

Portal

Navbar

Sidebar

Footer

Permissions

Routing

Session

Runtime

---

## APPS

portal

his

crm

pdv

financeiro

rh

estoque

farmacia

social

dashboard

admin

integrations

---

# 13. BACKEND CANÔNICO

src/

core/

domains/

portal/

social/

chat/

wiki/

dashboard/

integrations/

automation/

routes/

---

# 14. DISPATCHERS OFICIAIS

sp_master_dispatcher

sp_master_query_dispatcher

sp_master_auth

sp_master_portal

sp_master_social

sp_master_chat

sp_master_dashboard

sp_master_integration

sp_master_his

---

# 15. MOTORES CENTRAIS OBRIGATÓRIOS

Reutilizar sempre:

PESSOA

USUARIO

SESSAO_USUARIO

SISTEMA

UNIDADE

LOCAL

ALERTA

AGENDAMENTO

DOCUMENTO

EVENTO

AUDITORIA

---

# 16. PROIBIÇÕES ABSOLUTAS PARA IA

A IA NÃO PODE:

□ Criar tabelas sem autorização.

□ Criar Stored Procedures sem autorização.

□ Alterar Stored Procedures existentes.

□ Alterar ontologia.

□ Alterar fluxo.

□ Criar sistemas paralelos.

□ Criar autenticação paralela.

□ Criar agenda paralela.

□ Criar auditoria paralela.

□ Criar sessão paralela.

□ Criar workflow paralelo.

□ Renomear objetos canônicos.

□ Criar arquitetura alternativa.

---

# 17. REGRA FINAL

Quando houver dúvida:

NÃO IMPLEMENTAR.

NÃO INVENTAR.

NÃO SUPOR.

Primeiro consultar:

* Ontologia
* Dispatcher
* Stored Procedures
* Banco de Dados

Somente depois implementar.

FIM DA CONSTITUIÇÃO ARQUITETURAL DA PLATAFORMA NEW WAVE.
