O outro é o mais importante de todos. Ele é o que vai impedir a IA (Gemini, Claude, Kilo, Copilot, Codex, Cursor, Windsurf, etc.) de sair criando arquivos, tabelas, APIs e telas fora da arquitetura.

Eu chamaria de:

# ARQUITETURA_CANONICA_NEW_WAVE.md

```md
# NEW WAVE PLATFORM
# ARQUITETURA CANÔNICA OFICIAL

Status: IMUTÁVEL
Versão: 1.0

---

# OBJETIVO

Este documento define a arquitetura oficial da Plataforma New Wave.

Nenhuma IA, desenvolvedor ou ferramenta pode alterar esta arquitetura sem autorização explícita.

---

# REGRA 1
# O BANCO É A FONTE DA VERDADE

Frontend NÃO possui regra de negócio.

Backend NÃO possui regra de negócio.

Toda regra vive em:

Stored Procedures

---

# REGRA 2
# TRIGGERS PROIBIDOS

Não utilizar:

- Trigger
- Event Scheduler
- Cron SQL

Toda execução:

Dispatcher
↓
Executor
↓
Stored Procedure

---

# REGRA 3
# ORDEM ONTOLÓGICA

A plataforma inteira deve respeitar:

SAAS_ENTIDADE
↓
PESSOA
↓
VÍNCULO
↓
USUÁRIO
↓
SESSÃO_USUARIO
↓
SISTEMA
↓
UNIDADE
↓
LOCAL
↓
WORKFLOW
↓
EVENTO
↓
AUDITORIA

Nada pode pular etapas.

---

# REGRA 4
# PESSOA É A ENTIDADE RAIZ

PESSOA é a identidade real.

USUARIO é apenas credencial.

ERRADO:

Usuario
 ↓
Pessoa

CORRETO:

Pessoa
 ↓
Usuario

---

# REGRA 5
# MULTI TENANT

Toda entidade operacional deve possuir:

id_saas_entidade

Obrigatório.

---

# REGRA 6
# CONTEXTO OPERACIONAL

Nenhuma operação é anônima.

Toda operação exige:

id_sessao_usuario

A sessão determina:

- pessoa
- usuario
- sistema
- unidade
- local

---

# REGRA 7
# FRONTEND

Frontend apenas:

- Exibe
- Valida
- Consome APIs

Frontend nunca:

- Executa SQL
- Atualiza banco
- Contorna SP

---

# REGRA 8
# BACKEND

Backend apenas:

- Autentica
- Orquestra
- Chama Dispatcher

Backend nunca:

- INSERT direto
- UPDATE direto
- DELETE direto

---

# REGRA 9
# BANCO

Banco executa:

- Regras
- Validações
- Workflow
- Auditoria

---

# REGRA 10
# DISPATCHER

Toda gravação passa por:

sp_master_dispatcher

Fluxo:

Frontend
↓
API
↓
Dispatcher
↓
Executor
↓
SP

---

# REGRA 11
# QUERY

Consultas passam por:

sp_master_query_dispatcher

---

# REGRA 12
# SISTEMAS

A plataforma é SaaS Enterprise.

Não é HIS.

HIS é apenas um sistema.

Exemplos:

- Portal
- CRM
- ERP
- RH
- PDV
- Farmácia
- Financeiro
- Estoque
- Atendimento
- HIS

Todos são SISTEMAS.

---

# REGRA 13
# PORTAL

Portal é um sistema.

Não é núcleo.

Portal consome:

- Pessoa
- Usuário
- Sessão
- Alertas
- Agenda
- Arquivos

---

# REGRA 14
# ALERTAS

Não criar:

portal_notificacao

Utilizar:

alerta
alerta_destinatario
alerta_consumo

---

# REGRA 15
# CALENDÁRIO

Não criar:

portal_calendario

Utilizar:

agendamento

agenda_disponibilidade

---

# REGRA 16
# DOCUMENTOS

Não criar:

portal_arquivo

Utilizar:

documento_arquivo

reg_anexo

---

# REGRA 17
# AUDITORIA

Toda ação gera:

auditoria_evento

Nenhuma ação pode ser anônima.

---

# REGRA 18
# N8N

N8N é integração.

N8N não contém regra de negócio.

N8N nunca substitui:

- SP
- Dispatcher
- Workflow

N8N apenas:

- Integra
- Automatiza
- Notifica

---

# REGRA 19
# APIs

Estrutura:

Frontend
↓
API Gateway
↓
Backend
↓
Dispatcher
↓
Banco

---

# REGRA 20
# PROIBIÇÕES

Proibido:

- v2
- beta
- alpha
- legacy
- old
- novo
- copia

Nome único e canônico.

---

# REGRA 21
# FRONTEND CANÔNICO

Login
↓
Portal
↓
Seleção de Contexto
↓
Dashboard
↓
Sistema
↓
Tela Operacional

---

# REGRA 22
# ESTRUTURA DE CÓDIGO

apps/
shell/
core/
modules/
services/
api/
layouts/

Separação obrigatória.

---

# REGRA 23
# EVENTOS

Cada domínio possui seu próprio ledger.

Exemplos:

atendimento_evento_ledger

portal_evento_ledger

social_evento_ledger

Não misturar domínios.

---

# REGRA 24
# OBJETIVO FINAL

Construir uma plataforma SaaS Enterprise B2B/B2C multiempresa, multisistema, offline-first, auditável e orientada a workflow.

O HIS é apenas um dos sistemas hospedados pela plataforma.
```

Esses dois arquivos juntos viram praticamente a "Constituição" do projeto:

* **ARQUITETURA_CANONICA_NEW_WAVE.md** → define as leis.
* **TELAS_CANONICAS_PLATAFORMA.md** → define o que existe visualmente.

Qualquer IA que receber esses dois documentos antes de gerar código tende a produzir algo muito mais alinhado ao que vocês vêm desenhando.
